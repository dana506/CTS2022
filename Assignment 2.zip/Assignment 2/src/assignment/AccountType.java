package assignment;

public enum AccountType {
	STANDARD, BUDGET, PREMIUM, SUPER_PREMIUM;
}