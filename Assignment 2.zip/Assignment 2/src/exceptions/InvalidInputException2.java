package exceptions;

public class InvalidInputException2 extends Exception {

	public InvalidInputException2(String string) {

	}

}