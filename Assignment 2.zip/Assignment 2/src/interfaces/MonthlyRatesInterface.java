package interfaces;

public abstract interface MonthlyRatesInterface {
	public double computeMonthlyRate();
}